mpic++ mandelbrot_dynamic.cpp -lX11 -o mandelbrot_dynamic.out
mpirun -n 8 ./mandelbrot_dynamic.out 400 800 800

