mpic++ mandelbrot_pthread.cpp -lX11 -lpthread -o mandelbrot_pthread.out
./mandelbrot_pthread.out 8 800 800

