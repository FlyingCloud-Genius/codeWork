mpic++ mandelbrot_static.cpp -lX11 -o mandelbrot_static.out
mpirun -n 8 ./mandelbrot_static.out 800 800

