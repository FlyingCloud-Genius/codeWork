mpic++ mandelbrot.cpp -lX11 -o mandelbrot.out
./mandelbrot.out 800 800

